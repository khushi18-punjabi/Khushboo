import React, { useEffect, useState } from "react";
import {useNavigate} from 'react-router-dom';
import axios from 'axios';

const Login = () => {
    const [users, setUsers] = useState([]);
    const navigate = useNavigate();
    // const reqData = {
    //     email : value.email,
    //     password : value.password
    // };
    // useEffect(() => {
    //     const fetchData = async () => {
    //         const resdata = await axios.post(`https://espsofttech.in:6021/api/login`, { reqData });
    //         console.log(resdata);
    //         if(resdata.status==200){
    //             if(reqData.email=='mailto:xyz@gmail.com' && reqData.password=='123456'){
    //                 console.log(setUsers(users));
    //             }
    //         }
    //     };
    //     fetchData();
    // }, [setUsers]);

    const handleSignIn = async () => {
        const reqData = {
            email : "mailto:xyz@gmail.com",
            password : "123456"
        };
        const resdata = await axios.post(`https://espsofttech.in:6021/api/login`, { reqData });
        console.log(resdata);
        setUsers(resdata);
        return navigate('/product');
    };

    const handleSignOut=async()=>{
        return navigate('/register');
    }

    const handleCancel=async()=>{
        return navigate('/login');
    }

    return (
        <>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"></link>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
            <h4 className="text-center mt-3">Login Page</h4>
                <div className="container mt-3 mb-3 border">
                    <div className="row mb-3 mt-3">
                        <div className="col">
                            <label htmlFor="" className="form-label fw-bold">Email Id:</label>
                            <input type="text" className="form-control" id="txtEmail" placeholder="example@gmail.com"></input>
                        </div>
                    </div>
                    <div className="row mb-3">
                        <div className="col">
                            <label htmlFor="" className="form-label fw-bold">Password:</label>
                            <input type="password" className="form-control" id="txtPassword"></input>
                        </div>
                    </div>
                    <div className="row mt-3 mb-3">
                        <div className="col">
                            <div className="float-end">
                            <button type="submit" className="btn btn-primary" onClick={() => handleSignIn()}>SignIn</button>
                            <button type="submit" className="btn btn-secondary ms-3" onClick={() => handleSignOut()}>SignOut</button>
                            <button type="button" className="btn btn-danger ms-3" onClick={() => handleCancel()}>Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
        </>
    );
}

export default Login;
