import React, { useEffect, useState } from "react";
import axios from 'axios';
import { useNavigate } from "react-router-dom";

const Register = () => {
    const [users, setUsers] = useState([]);
    const navigate = useNavigate();
    // const reqData = {
    //     first_name: "xyz",
    //     last_name: "xyzz",
    //     email: "mailto:xyz@gmail.com",
    //     password: "123456",
    //     confirm_password: "123456"
    // };
    // useEffect(() => {
    //     const fetchData = async () => {
    //         const data = await axios.post(`https://espsofttech.in:6021/api/userRegister`, { reqData }
    //         );
    //         console.log(data);
    //         console.log(reqData);
    //         setUsers(data);
    //     };
    //     fetchData();
    // }, [setUsers]);

    const handleSignOut = async () => {
        const reqData = {
            first_name: "xyz",
            last_name: "xyzz",
            email: "mailto:xyz@gmail.com",
            password: "123456",
            confirm_password: "123456"
        };
        const resdata = await axios.post(`https://espsofttech.in:6021/api/login`, { reqData });
        console.log(resdata);
        setUsers(resdata);
        return navigate('/login');
    };

    const handleCancel=async()=>{
        return navigate('/register');
    }
    return (
        <>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"></link>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
            <h4 className="text-center mt-3">Registration Page</h4>
            <div className="container mt-3 mb-3 border">
                <div className="row mb-3 mt-3">
                    <div className="col">
                        <label htmlfor="" className="form-label fw-bold">First Name:</label>
                        <input type="text" className="form-control" id="txtFirstName" placeholder="Enter First Name"></input>
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col">
                        <label htmlfor="" className="form-label fw-bold">Last Name:</label>
                        <input type="text" className="form-control" id="txtLastName" placeholder="Enter Last Name"></input>
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col">
                        <label htmlfor="" className="form-label fw-bold">Email Id:</label>
                        <input type="email" className="form-control" id="txtEmail" placeholder="example@gmail.com"></input>
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col">
                        <label htmlfor="" className="form-label fw-bold">Password:</label>
                        <input type="password" className="form-control" id="txtPassword"></input>
                    </div>
                </div>
                <div className="row">
                    <div className="col">
                        <label htmlfor="" className="form-label fw-bold">Confirm Password:</label>
                        <input type="password" className="form-control" id="txtConfirmPassword"></input>
                    </div>
                </div>
                <div className="row mt-3 mb-3">
                    <div className="col">
                        <div className="float-end">
                            <button type="submit" className="btn btn-success" onClick={() => handleSignOut()}>Submit</button>
                            <button type="button" className="btn btn-danger ms-3" onClick={() => handleCancel()}>Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Register;
