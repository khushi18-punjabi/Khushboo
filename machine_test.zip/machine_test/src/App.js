import {Route, Routes} from 'react-router-dom';
import Login from '../src/Containers/Login';
import Register from '../src/Containers/Register';
import Product from '../src/Containers/Product';

const App = () => {
  return (
      <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/product" element={<Product />} />
      </Routes>
  );
};

export default App;